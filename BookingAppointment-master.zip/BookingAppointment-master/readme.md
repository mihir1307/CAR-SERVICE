# Appointment Booking

### by Alex Ficklin & Ron Craig

## A website to book an appointment, version 1.01, 01/10/2018

## Description

### A HTML site is used to book an appointment.  The user inputs name, details about the appointment, date, start and end times.  Appointment is successful when user 'presses' the Book Appointment button.

## Setup/Installation Requirements

* Bootstrap, clone from GitHub, open with HTML.

## Known Bugs

_No known bugs_

## Support and contact details

_If you run into any issues, please contact either Ron Craig [ron.craig@comcast.net] or Alex Ficklin [akk.aol.com, just kidding]_

## Technologies Used

_Bootstrap, CSS and HTML_

### License
*MIT*

Copyright (c) 2018 **_AFRC Corporation**
